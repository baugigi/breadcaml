(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Mcu: Gpio sul user port (porta B), tempi, impulsi; i controlli sui pin sollevano Invalid_argument *)
open C64
let t_gpio () =
  Mcu.Gpio.mode 0 Mcu.Gpio.Output; Mcu.Gpio.mode 1 Mcu.Gpio.Output; Mcu.Gpio.mode 2 Mcu.Gpio.Input;
  Mcu.Gpio.write 0 true; Mcu.Gpio.write 1 false;
  check "write" (Mcu.Gpio.read 0 = true && Mcu.Gpio.read 1 = false);
  Mcu.Gpio.toggle 0; Mcu.Gpio.toggle 1;
  check "toggle" (Mcu.Gpio.read 0 = false && Mcu.Gpio.read 1 = true);
  Mcu.Gpio.write_port 0; Mcu.Gpio.mode 3 Mcu.Gpio.Output;
  for p = 0 to 7 do Mcu.Gpio.mode p Mcu.Gpio.Output done;
  Mcu.Gpio.write_port 0xA5;
  check "port" (Mcu.Gpio.read_port () = 0xA5);
  Mcu.Gpio.mode 8 Mcu.Gpio.Output;                (* il pin 8 e' PA2 *)
  Mcu.Gpio.write 8 true;
  check "pa2" (Mcu.Gpio.read 8 = true);
  Mcu.Gpio.write 8 false;
  check "pa2-low" (Mcu.Gpio.read 8 = false);
  Mcu.Gpio.mode 8 Mcu.Gpio.Input;
  raises_inv "pin-neg" (fun () -> Mcu.Gpio.mode (-1) Mcu.Gpio.Output);
  raises_inv "pin-9" (fun () -> Mcu.Gpio.write 9 true);
  raises_inv "read-9" (fun () -> Mcu.Gpio.read 9)
let t_time () =
  check "cycles" (Mcu.Time.cycles_of_us 1000 > 0);
  Mcu.Time.clock_start ();
  Mcu.Time.delay_ms 20;
  let t = Mcu.Time.clock_ticks () in
  check "ticks" (t > 0);
  check "tpm" (Mcu.Time.ticks_per_ms () > 0);
  Mcu.Time.delay_us 100; Mcu.Time.delay_cycles 100
let t_pulse () =
  Mcu.Gpio.mode 0 Mcu.Gpio.Output;
  Mcu.Pulse.out 0 ~us:200;
  Mcu.Pulse.out ~level:false 0 ~us:100;
  Mcu.Pulse.out 0 ~us:50;                          (* sotto l'overhead: impulso minimo *)
  raises_inv "pulse-neg" (fun () -> Mcu.Pulse.out 0 ~us:(-1));
  raises_inv "pulse-long" (fun () -> Mcu.Pulse.out 0 ~us:16500);
  raises_inv "pulse-pin" (fun () -> Mcu.Pulse.out 8 ~us:10);
  Mcu.Gpio.mode 1 Mcu.Gpio.Input;
  check "pulse-width-timeout" (Mcu.Pulse.width ~timeout_ms:5 1 = -1);
  raises_inv "pulse-timeout" (fun () -> Mcu.Pulse.width ~timeout_ms:5000 1)
let t_spi () =
  let s = Mcu.Spi.create () in
  Mcu.Spi.write s 0x55;
  check "spi" true
let () =
  run "gpio" t_gpio; run "time" t_time; run "pulse" t_pulse; run "spi" t_spi;
  Hw.Userport.set_ddr 0;
  finish "TC06"
