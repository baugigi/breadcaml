(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Sprite: registri VIC, saturazione degli argomenti, definizione dei blocchi (bank 2, -mem 0x7FFF) *)
open C64
let vic = Hw.Vic.peek
let t_pos () =
  Gfx.init Gfx.bank2; Sprite.setup Gfx.bank2;
  Sprite.pos 3 100 120;
  check "pos" (vic (Hw.Vic.mx 3) = 100 && vic (Hw.Vic.my 3) = 120 && vic Hw.Vic.mx8 land 8 = 0);
  Sprite.pos 3 300 120;
  check "pos-msb" (vic (Hw.Vic.mx 3) = 300 land 255 && vic Hw.Vic.mx8 land 8 <> 0);
  Sprite.pos 3 20 120;
  check "pos-msb-clr" (vic Hw.Vic.mx8 land 8 = 0);
  Sprite.pos 9 600 100;                    (* n -> 7, x -> 511 *)
  check "sat-n" (vic (Hw.Vic.mx 7) = 255 && vic Hw.Vic.mx8 land 128 <> 0 && vic (Hw.Vic.my 7) = 100);
  Sprite.pos (-3) (-9) 10;                 (* n -> 0, x -> 0 *)
  check "sat-neg" (vic (Hw.Vic.mx 0) = 0 && vic Hw.Vic.mx8 land 1 = 0 && vic (Hw.Vic.my 0) = 10);
  Sprite.move 1 0 0;
  check "move" (vic (Hw.Vic.mx 1) = 24 && vic (Hw.Vic.my 1) = 50)
let t_flags () =
  Sprite.enable 2 true;
  check "enable" (vic Hw.Vic.me land 4 <> 0);
  Sprite.enable 2 false;
  check "disable" (vic Hw.Vic.me land 4 = 0);
  Sprite.enable 99 true;                   (* saturato a 7 *)
  check "enable-sat" (vic Hw.Vic.me land 128 <> 0);
  Sprite.enable 7 false;
  Sprite.expand_x 1 true; Sprite.expand_y 1 true;
  check "expand" (vic Hw.Vic.mxe land 2 <> 0 && vic Hw.Vic.mye land 2 <> 0);
  Sprite.expand_x 1 false; Sprite.expand_y 1 false;
  check "unexpand" (vic Hw.Vic.mxe land 2 = 0 && vic Hw.Vic.mye land 2 = 0);
  Sprite.multicolor 4 true;
  check "multicolor" (vic Hw.Vic.mmc land 16 <> 0);
  Sprite.multicolor 4 false;
  Sprite.behind 5 true;
  check "behind" (vic Hw.Vic.mdp land 32 <> 0);
  Sprite.behind 5 false;
  Sprite.color 6 9;
  check "color" (vic (Hw.Vic.mc 6) land 15 = 9);
  Sprite.mcolors 4 5;
  check "mcolors" (vic Hw.Vic.mm0 land 15 = 4 && vic Hw.Vic.mm1 land 15 = 5)
let t_define () =
  let l = Sprite.layout () in
  check "layout" (l = Gfx.bank2);
  Sprite.define 16 (Array.init 63 (fun i -> i));
  Sprite.assign 0 16;
  (* il blocco 16 sta a $8000 + 16*64 = $8400 *)
  check "define" (Hw.Mem.peek_at ~ram:true 0x84 0 = 0 && Hw.Mem.peek_at ~ram:true 0x84 62 = 62);
  check "pointer" (Hw.Mem.peek_at ~ram:true 0x83 0xF8 = 16);
  Sprite.define_string 17 (String.make 63 'x');
  check "define_string" (Hw.Mem.peek_at ~ram:true 0x84 0x40 = Char.code 'x');
  let art = Array.make 21 (String.make 24 ' ') in
  art.(0) <- "#" ^ String.make 23 '.';
  art.(20) <- String.make 23 '.' ^ "#";
  Sprite.define_art 18 art;
  check "art-first" (Hw.Mem.peek_at ~ram:true 0x84 0x80 = 0x80);
  check "art-last" (Hw.Mem.peek_at ~ram:true 0x84 (0x80 + 62) = 0x01);
  check "art-empty" (Hw.Mem.peek_at ~ram:true 0x84 0x81 = 0);
  let mc = Array.make 21 (String.make 12 '0') in
  mc.(0) <- "123" ^ String.make 9 '0';
  Sprite.define_art_mc 19 mc;
  check "mc-art" (Hw.Mem.peek_at ~ram:true 0x84 0xC0 = 0b01_10_11_00)
let t_hit () =
  ignore (Sprite.hit_sprites ()); ignore (Sprite.hit_background ());
  check "hit-clear" (Sprite.hit_sprites () = 0 && Sprite.hit_background () = 0)
let () =
  run "pos" t_pos; run "flags" t_flags; run "define" t_define; run "hit" t_hit;
  Gfx.exit ();
  finish "TC04"
