(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Gfx: bitmap hires/multicolor a 320x200 (bank 2, -mem 0x7FFF): clipping, linee, forme, finestra *)
open C64
(* numero di pixel accesi (hires): conta i bit della bitmap ($A000-$BF3F, RAM sotto la BASIC ROM) *)
let nib = Array.init 16 (fun b -> let n = ref 0 in for i = 0 to 3 do if b land (1 lsl i) <> 0 then incr n done; !n)   (* i blocchi hanno al massimo 255 word *)
let pop b = nib.(b land 15) + nib.(b lsr 4)
let count () =
  let n = ref 0 in
  Hw.Nmi.block ();
  for page = 0xA0 to 0xBE do
    for off = 0 to 255 do n := !n + pop (Hw.Mem.peek_at_ram page off) done
  done;
  for off = 0 to 0x3F do n := !n + pop (Hw.Mem.peek_at_ram 0xBF off) done;
  Hw.Nmi.unblock ();
  !n
let t_basic () =
  Gfx.init Gfx.bank2;
  Gfx.clear ();
  check "w" (Gfx.width () = 320 && Gfx.height = 200);
  Gfx.pen 1;
  Gfx.plot 10 10;
  check "plot" (Gfx.point 10 10 = 1 && Gfx.point 11 10 = 0 && Gfx.point 10 11 = 0);
  Gfx.pen 0; Gfx.plot 10 10;
  check "erase" (Gfx.point 10 10 = 0);
  Gfx.pen 1;
  Gfx.plot 0 0; Gfx.plot 319 199;
  check "corners" (Gfx.point 0 0 = 1 && Gfx.point 319 199 = 1);
  check "outside" (Gfx.point (-1) 0 = -1 && Gfx.point 0 (-1) = -1 && Gfx.point 320 0 = -1 && Gfx.point 0 200 = -1)
let t_clip () =
  Gfx.clear ();
  Gfx.pen 1;
  Gfx.plot (-1) 5; Gfx.plot 320 5; Gfx.plot 5 (-1); Gfx.plot 5 200; Gfx.plot 16000 16000; Gfx.plot (-16000) (-16000);
  check "clip-none" (count () = 0)
let t_lines () =
  Gfx.clear (); Gfx.pen 1;
  Gfx.hline 10 20 5;
  check "hline" (count () = 11 && Gfx.point 10 5 = 1 && Gfx.point 20 5 = 1 && Gfx.point 21 5 = 0);
  Gfx.clear (); Gfx.vline 7 3 9;
  check "vline" (count () = 7 && Gfx.point 7 3 = 1 && Gfx.point 7 9 = 1);
  Gfx.clear (); Gfx.line 0 0 99 99;
  check "diag" (count () = 100 && Gfx.point 50 50 = 1);
  Gfx.clear (); Gfx.line 99 99 0 0;
  check "diag-rev" (count () = 100);
  Gfx.clear (); Gfx.line (-50) 10 369 10;       (* clippata: l'intera riga *)
  check "line-clip" (count () = 320 && Gfx.point 0 10 = 1 && Gfx.point 319 10 = 1);
  Gfx.clear (); Gfx.line (-100) (-100) (-50) (-50);
  check "line-out" (count () = 0)
let t_shapes () =
  Gfx.clear (); Gfx.pen 1;
  Gfx.rect 10 10 19 14;
  check "rect" (count () = 2 * 10 + 2 * 3 && Gfx.point 10 10 = 1 && Gfx.point 15 12 = 0);
  Gfx.clear (); Gfx.fill_rect 10 10 19 14;
  check "fill_rect" (count () = 50 && Gfx.point 15 12 = 1);
  Gfx.clear (); Gfx.circle 100 100 0;
  check "circle0" (count () = 1 && Gfx.point 100 100 = 1);
  Gfx.clear (); Gfx.circle 100 100 (-5);        (* r < 0 vale 0 *)
  check "circle-neg" (count () = 1 && Gfx.point 100 100 = 1);
  Gfx.clear (); Gfx.circle 100 100 10;
  check "circle" (Gfx.point 110 100 = 1 && Gfx.point 90 100 = 1 && Gfx.point 100 110 = 1
                  && Gfx.point 100 90 = 1 && Gfx.point 100 100 = 0);
  Gfx.clear (); Gfx.fill_circle 100 100 10;
  check "fill_circle" (Gfx.point 100 100 = 1 && Gfx.point 108 100 = 1 && Gfx.point 111 100 = 0);
  Gfx.clear (); Gfx.circle 0 0 20;               (* parzialmente fuori: clippata *)
  check "circle-clip" (count () > 0)
let t_window () =
  Gfx.clear (); Gfx.pen 1;
  Gfx.window 0 0 31 19;                           (* (0,0)-(31,19) -> (0,0)-(319,199) *)
  Gfx.plot 0 0; Gfx.plot 31 19;
  check "win-virtual" (Gfx.point 0 0 = 1 && Gfx.point 31 19 = 1 && Gfx.point 5 5 = 0);   (* anche point e' virtuale *)
  Gfx.unwindow ();
  check "win-physical" (Gfx.point 0 0 = 1 && Gfx.point 319 199 = 1 && Gfx.point 31 19 = 0);
  Gfx.clear ();
  Gfx.window 319 199 0 0;                         (* assi invertiti *)
  Gfx.plot 319 199;
  Gfx.unwindow ();
  check "win-flip" (Gfx.point 0 0 = 1 && Gfx.point 319 199 = 0);
  Gfx.clear ();
  Gfx.window 0 0 160 100;                         (* meta' risoluzione: 2x *)
  Gfx.plot 80 50;
  Gfx.unwindow ();
  check "win-2x" (count () = 1 && (Gfx.point 159 99 = 1 || Gfx.point 160 100 = 1 || Gfx.point 159 100 = 1 || Gfx.point 160 99 = 1));
  raises_inv "win-small" (fun () -> Gfx.window 0 0 1 100)
let t_colors () =
  Gfx.colors ~ink:1 ~paper:6;
  Gfx.fill_screen 0x16;
  check "scr" (Hw.Mem.peek_at ~ram:true 0x80 0 = 0x16);
  Gfx.background 3;
  check "bg" (Hw.Vic.peek Hw.Vic.b0c land 15 = 3)
let t_mc () =
  Gfx.init ~mode:Gfx.Multicolor Gfx.bank2;
  Gfx.clear ();
  check "mc-w" (Gfx.width () = 160);
  for p = 0 to 3 do Gfx.pen p; Gfx.plot (10 + p) 10 done;
  check "mc-pens" (Gfx.point 10 10 = 0 && Gfx.point 11 10 = 1 && Gfx.point 12 10 = 2 && Gfx.point 13 10 = 3);
  check "mc-out" (Gfx.point 160 0 = -1);
  Gfx.exit ();
  Gfx.init Gfx.bank2
let () =
  run "basic" t_basic; run "clip" t_clip; run "lines" t_lines; run "shapes" t_shapes;
  run "window" t_window; run "colors" t_colors; run "mc" t_mc;
  Gfx.exit ();
  finish "TC03"
