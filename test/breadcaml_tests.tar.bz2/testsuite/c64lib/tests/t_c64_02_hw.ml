(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Hw: Mem (short/page form, sotto le ROM, protezioni), fill/blit, registri VIC/SID, user port *)
open C64
let t_mem () =
  let a = -0x4000 in                             (* forma short per $C000 *)
  Hw.Mem.poke a 0x5A;
  check "poke/peek" (Hw.Mem.peek a = 0x5A);
  check "peek_at" (Hw.Mem.peek_at 0xC0 0 = 0x5A);
  Hw.Mem.poke_at 0xC0 1 0x1FF;
  check "mask8" (Hw.Mem.peek_at 0xC0 1 = 0xFF);
  Hw.Mem.unsafe_poke (a + 2) 0x33;
  check "unsafe" (Hw.Mem.peek (a + 2) = 0x33);
  check "view" (Hw.Mem.peek_view a = 0x5A && Hw.Mem.peek_at_view 0xC0 0 = 0x5A)
let t_prot () =
  raises_inv "poke-screen" (fun () -> Hw.Mem.poke 0x0400 1);
  raises_inv "poke-prog"   (fun () -> Hw.Mem.poke 0x0900 1);
  raises_inv "poke-zp"     (fun () -> Hw.Mem.poke 0x0002 1);
  raises_inv "fill-prot"   (fun () -> Hw.Mem.fill 0x0400 4 0);
  raises_inv "fill-neg"    (fun () -> Hw.Mem.fill (-0x3F00) (-1) 0);
  raises_inv "blit-prot"   (fun () -> Hw.Mem.blit (-0x4000) 0x0400 4)
let t_fillblit () =
  let b = -0x3F00 in                             (* $C100 *)
  Hw.Mem.fill b 16 0x77;
  check "fill" (Hw.Mem.peek b = 0x77 && Hw.Mem.peek (b + 15) = 0x77 && Hw.Mem.peek (b + 16) <> 0x77);
  for i = 0 to 7 do Hw.Mem.poke (b + i) (i + 1) done;
  Hw.Mem.blit b (b + 2) 6;                         (* sovrapposta, in avanti *)
  check "blit-fwd" (Hw.Mem.peek (b + 2) = 1 && Hw.Mem.peek (b + 7) = 6);
  for i = 0 to 7 do Hw.Mem.poke (b + i) (i + 1) done;
  Hw.Mem.blit (b + 2) b 6;                         (* sovrapposta, all'indietro *)
  check "blit-bwd" (Hw.Mem.peek b = 3 && Hw.Mem.peek (b + 5) = 8);
  Hw.Mem.fill_at 0xC1 0x80 4 0x11;
  check "fill_at" (Hw.Mem.peek_at 0xC1 0x80 = 0x11 && Hw.Mem.peek_at 0xC1 0x83 = 0x11);
  Hw.Mem.blit_at 0xC1 0x80 0xC1 0x90 4;
  check "blit_at" (Hw.Mem.peek_at 0xC1 0x93 = 0x11);
  Hw.Mem.unsafe_fill b 2 0x44;
  check "unsafe_fill" (Hw.Mem.peek b = 0x44)
let t_ram () =
  (* RAM sotto la BASIC ROM ($A000): la vista CPU resta la ROM *)
  Hw.Nmi.block ();
  Hw.Mem.unsafe_poke_at 0xA0 0 0x5A;
  check "rom-view" (Hw.Mem.peek_at 0xA0 0 = 0x94);         (* BASIC ROM: $A000 = $94 *)
  check "ram-view" (Hw.Mem.peek_at ~ram:true 0xA0 0 = 0x5A);
  check "ram-fast" (Hw.Mem.peek_at_ram 0xA0 0 = 0x5A);
  Hw.Nmi.unblock ()
let t_regs () =
  Hw.Vic.poke Hw.Vic.ec 7;
  check "vic" (Hw.Vic.peek Hw.Vic.ec land 15 = 7);
  Hw.Vic.poke Hw.Vic.ec 14;
  check "vic-mx" (Hw.Vic.mx 3 = 6 && Hw.Vic.my 3 = 7 && Hw.Vic.mc 2 = 0x29);
  Hw.Sid.poke Hw.Sid.modvol 15;
  check "sid-offs" (Hw.Sid.voice 2 = 7 && Hw.Sid.voice 3 = 14)
let t_userport () =
  Hw.Userport.set_ddr 0xFF;
  check "ddr" (Hw.Userport.ddr () = 0xFF);
  Hw.Userport.write 0xA5;
  check "write/read" (Hw.Userport.read () = 0xA5);
  Hw.Userport.write 0;
  Hw.Userport.set_bits 0x81;
  check "set" (Hw.Userport.read () = 0x81);
  Hw.Userport.toggle_bits 0x01;
  check "toggle" (Hw.Userport.read () = 0x80);
  Hw.Userport.clear_bits 0x80;
  check "clear" (Hw.Userport.read () = 0);
  Hw.Userport.dir_in 0x0F;
  check "dir_in" (Hw.Userport.ddr () = 0xF0);
  Hw.Userport.dir_out 0x01;
  check "dir_out" (Hw.Userport.ddr () = 0xF1);
  Hw.Userport.set_ddr 0
let () =
  run "mem" t_mem; run "prot" t_prot; run "fillblit" t_fillblit;
  run "ram" t_ram; run "regs" t_regs; run "userport" t_userport;
  finish "TC02"
