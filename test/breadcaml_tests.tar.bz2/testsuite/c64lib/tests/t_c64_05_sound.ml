(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Sound: registri SID tramite lo shadow, saturazione degli argomenti *)
open C64
let sh = Sound.shadow
let t_voice () =
  Sound.waveform 1 Sound.saw;
  check "waveform" (sh 4 land 0xF0 = Sound.saw);
  Sound.gate 1 true;
  check "gate" (sh 4 land 1 = 1 && sh 4 land 0xF0 = Sound.saw);
  Sound.gate 1 false;
  check "gate-off" (sh 4 land 1 = 0);
  Sound.sync 2 true; Sound.ring 2 true; Sound.test 2 true;
  check "flags" (sh 11 land 0x0E = 0x0E);
  Sound.sync 2 false; Sound.ring 2 false; Sound.test 2 false;
  check "flags-off" (sh 11 land 0x0E = 0);
  Sound.adsr 3 ~a:5 ~d:6 ~s:7 ~r:8;
  check "adsr" (sh 19 = 0x56 && sh 20 = 0x78);
  Sound.pulse_width 1 0x0ABC;
  check "pw" (sh 2 = 0xBC && sh 3 = 0x0A);
  Sound.freq_raw 2 ~hi:0x12 ~lo:0x34;
  check "freq_raw" (sh 7 = 0x34 && sh 8 = 0x12)
let t_sat () =
  Sound.note 3 95;
  let l = sh 14 and h = sh 15 in
  Sound.note 9 200;
  check "note-sat" (sh 14 = l && sh 15 = h);
  Sound.freq_hz 1 0;
  let l = sh 0 and h = sh 1 in
  Sound.freq_hz 1 (-5);
  check "hz-sat-neg" (sh 0 = l && sh 1 = h);
  Sound.freq_hz 1 (Sound.max_hz ());
  let l = sh 0 and h = sh 1 in
  Sound.freq_hz 1 (Sound.max_hz () + 1000);
  check "hz-sat-max" (sh 0 = l && sh 1 = h)

let t_misc () =
  Sound.volume 10;
  check "volume" (sh 24 land 15 = 10);
  Sound.route 1 true;
  check "route" (sh 23 land 1 = 1);
  Sound.route 1 false;
  check "route-off" (sh 23 land 1 = 0);
  Sound.filter_mode ~lp:true ~bp:false ~hp:true;
  check "filter" (sh 24 land 0x70 = 0x50);
  Sound.mute_voice3 true;
  check "mute3" (sh 24 land 0x80 <> 0);
  Sound.mute_voice3 false;
  Sound.play 1 60;
  check "play" (sh 4 land 1 = 1);
  Sound.stop 1;
  check "stop" (sh 4 land 1 = 0);
  Sound.silence ();
  check "silence" (sh 24 land 15 = 0);
  check "f4" (Sound.f4_of_hz 0 = 0 && Sound.f4_of_hz 100 > 0)
let t_rand () =
  Sound.random_init ();
  let a = Sound.random () in
  let b = ref false in
  for _ = 1 to 50 do if Sound.random () <> a then b := true done;
  check "random-varies" !b;
  Sound.silence ()
let () =
  run "voice" t_voice; run "sat" t_sat; run "misc" t_misc; run "rand" t_rand;
  finish "TC05"
