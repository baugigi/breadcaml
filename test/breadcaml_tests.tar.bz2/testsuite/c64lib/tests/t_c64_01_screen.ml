(* ---- prelude comune (generato da gen_tests.py) ---- *)
let fails = ref 0
let fail s = incr fails; print_string "FAIL "; print_string s; print_newline ()
let check s ok = if not ok then fail s
let checkn s n ok = if not ok then fail (s ^ string_of_int n)
let check2 s m n ok =
  if not ok then fail (s ^ string_of_int m ^ "," ^ string_of_int n)
let run s f = try f () with _ -> fail (s ^ " EXN")
let raises_inv s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Invalid_argument _ -> () | _ -> fail (s ^ " BADEXN")
let raises_dz s f =
  try ignore (f ()); fail (s ^ " NOEXN")
  with Division_by_zero -> () | _ -> fail (s ^ " BADEXN")
let finish t =
  print_string t;
  if !fails = 0 then print_string " OK" else print_string " FAIL";
  print_newline ()
(* ---- fine prelude ---- *)
(* C64.Screen: accesso diretto, saturazione, riempimenti, cursore, scroll, colori del bordo *)
open C64
let t_sat () =
  Screen.clear ();
  Screen.put 0 0 1;  Screen.put (-5) (-5) 2;
  check "put-neg" (Screen.get 0 0 = 2);
  Screen.put 100 100 3;
  check "put-big" (Screen.get 39 24 = 3);
  Screen.put 39 0 4; Screen.put 40 0 5;
  check "put-x40" (Screen.get 39 0 = 5);
  check "get-neg" (Screen.get (-1) (-1) = 2);
  check "get-big" (Screen.get 99 99 = 3);
  Screen.put_color 1 1 7; Screen.put_color 99 99 6;
  check "col" (Screen.get_color 1 1 = 7);
  check "col-sat" (Screen.get_color 39 24 = 6);
  check "col-get-sat" (Screen.get_color 99 99 = 6)
let t_print () =
  Screen.clear ();
  Screen.print_at 38 1 "ABCDE";
  check "pa-right" (Screen.get 38 1 = Screen.code_of_char 'A' && Screen.get 39 1 = Screen.code_of_char 'B');
  Screen.print_at (-2) 2 "ABCDE";
  check "pa-left" (Screen.get 0 2 = Screen.code_of_char 'C' && Screen.get 2 2 = Screen.code_of_char 'E');
  Screen.print_at 5 99 "Z";
  check "pa-row" (Screen.get 5 24 = Screen.code_of_char 'Z');
  Screen.print_at ~color:2 0 3 "AB";
  check "pa-color" (Screen.get_color 0 3 = 2 && Screen.get_color 1 3 = 2);
  Screen.print_at 0 4 "";
  Screen.put_char 7 7 'q';
  check "put_char" (Screen.get_char 7 7 = 'q')
let t_conv () =
  for c = 32 to 95 do
    checkn "rt" c (Char.code (Screen.char_of_code (Screen.code_of_char (Char.chr c))) = c)
  done;
  check "A" (Screen.code_of_char 'A' = 65);
  check "@" (Screen.code_of_char '@' = 0);
  check "sp" (Screen.code_of_char ' ' = 32);
  check "ctl" (Screen.code_of_char '\001' = 32 && Screen.code_of_char '\130' = 32)
let t_fill () =
  Screen.fill 5;
  check "fill" (Screen.get 0 0 = 5 && Screen.get 39 24 = 5 && Screen.get 20 12 = 5);
  Screen.fill_color 3;
  check "fill_color" (Screen.get_color 0 0 = 3 && Screen.get_color 39 24 = 3);
  Screen.clear ();
  check "clear" (Screen.get 0 0 = 32 && Screen.get 39 24 = 32)
let t_cursor () =
  Screen.home ();
  check "home" (Screen.cursor () = (0, 0));
  Screen.locate 5 7;
  check "locate" (Screen.cursor () = (5, 7));
  Screen.locate (-3) 99;
  check "locate-sat1" (Screen.cursor () = (0, 24));
  Screen.locate 99 (-1);
  check "locate-sat2" (Screen.cursor () = (39, 0));
  Screen.home ()
let t_scroll () =
  Screen.clear ();
  Screen.put 0 1 7; Screen.put 3 24 9;
  Screen.scroll_up ();
  check "up-moved" (Screen.get 0 0 = 7);
  check "up-last-cleared" (Screen.get 3 24 = 32);
  check "up-24" (Screen.get 3 23 = 9);
  Screen.put 0 0 8;
  Screen.scroll_down ();
  check "down-moved" (Screen.get 0 1 = 8);
  check "down-first-cleared" (Screen.get 0 0 = 32)
let t_colors () =
  Screen.border 5; Screen.background 6;
  check "border" (Hw.Vic.peek Hw.Vic.ec land 15 = 5);
  check "background" (Hw.Vic.peek Hw.Vic.b0c land 15 = 6);
  Screen.border 14; Screen.background 6
let () =
  run "sat" t_sat; run "print" t_print; run "conv" t_conv; run "fill" t_fill;
  run "cursor" t_cursor; run "scroll" t_scroll; run "colors" t_colors;
  finish "TC01"
