let () = try raise Not_found with Not_found -> print_string "M8 OK"
