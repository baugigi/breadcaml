let mk n = fun x -> x + n
let () = let h = mk 5 in if h 37 = 42 then print_string "M7 OK" else print_string "M7 FAIL"
