let () = let t = (1, 2, 3) in
  let (a, b, c) = t in
  if a + b + c = 6 then print_string "M6 OK" else print_string "M6 FAIL"
