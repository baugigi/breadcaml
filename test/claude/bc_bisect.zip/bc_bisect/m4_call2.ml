let g x y = x * 2 + y
let () = if g 20 2 = 42 then print_string "M4 OK" else print_string "M4 FAIL"
