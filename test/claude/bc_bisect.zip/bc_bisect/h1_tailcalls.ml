(* Chiamate in coda (APPTERM) con n=1..4 argomenti e s-n = 0..3 variabili locali.
   Atteso: "YYYYYYYYYYYY" poi "H OK" (ogni N indica il caso errato, nell'ordine sotto). *)
let ok = ref true
let say b = if b then print_string "Y" else (ok := false; print_string "N")
let k = ref 5                       (* evita il constant folding *)
let a1 x = x = !k
let a2 x y = x = !k && y = !k + 1
let a3 x y z = x = !k && y = !k + 1 && z = !k + 2
let a4 x y z w = x = !k && y = !k + 1 && z = !k + 2 && w = !k + 3
(* APPTERM 1 / 2 / 3 / 4, nessuna variabile locale oltre all'argomento unit *)
let t1_0 () = a1 !k
let t2_0 () = a2 !k (!k + 1)
let t3_0 () = a3 !k (!k + 1) (!k + 2)
let t4_0 () = a4 !k (!k + 1) (!k + 2) (!k + 3)
(* con 2 variabili locali *)
let t1_2 () = let p = !k in let q = p + 1 in if q = 0 then false else a1 p
let t2_2 () = let p = !k in let q = p + 1 in if q = 0 then false else a2 p q
let t3_2 () = let p = !k in let q = p + 1 in let r = q + 1 in if r = 0 then false else a3 p q r
let t4_2 () = let p = !k in let q = p + 1 in let r = q + 1 in let s = r + 1 in
              if s = 0 then false else a4 p q r s
(* con record locale (come t1 di t01a) *)
type r1 = { mutable x : int }
let t2_r () = let r = { x = !k } in r.x <- r.x + 0; a2 r.x (r.x + 1)
let () =
  say (t1_0 ()); say (t2_0 ()); say (t3_0 ()); say (t4_0 ());
  say (t1_2 ()); say (t2_2 ()); say (t3_2 ()); say (t4_2 ());
  say (t2_r ());
  print_newline ();
  print_string (if !ok then "H OK" else "H FAIL");
  print_newline ()
