Scala di bisect per bytecode (bcamlc): compilare ognuno con "-o out.prg src.ml" e lanciare in ordine.
Il primo che non stampa "Mx OK" indica la funzionalita' guasta:
 m0 avvio/STOP, m1 CCALL+stringa, m2 confronto+BIF, m3 APPLY1/RETURN, m4 APPLY2/GRAB,
 m5 ref/OFFSETREF/SETFIELD, m6 MAKEBLOCK/GETFIELD, m7 CLOSURE/ENVACC, m8 PUSHTRAP/RAISE, m9 stringhe/concat.
Hang gia' in m0 => loader/caml_init/fetch-exec/STOP; in m1 => CCALL/tabella esterni.

Seconda scala (con il prelude dei test completi):
 p0 solo prelude+finish (atteso "P0 OK"), p1 check vero ("P1 OK"), p2 check falso
 (atteso "FAIL c2" e "P2 FAIL"), p3 run con eccezione ("FAIL r2 EXN", "P3 FAIL"),
 p4 checkn/check2 (string_of_int, ^: "FAIL n7", "FAIL k3,4", "P4 FAIL").

Terza scala (t01a ridotto): stesse definizioni di t01a_small, ma si esegue solo un gruppo.
 u00 nessun gruppo (solo caricamento del programma grande: atteso "U OK")
 u01..u10 un solo tN, u11.. variants/tuple; u99 tutti i gruppi (=t01a).
Se u00 va in hang -> problema di dimensione/caricamento (tabella globali, indirizzi, blocchi statici).
Se u00 passa ma un uNN no -> bug nelle istruzioni usate da quel gruppo.

Quarta scala (dal log di t01a: stringhe di FAIL puntano a RAM non inizializzata = pattern 00 00 00 00 FF FF FF FF di VICE):
 g1a/g1b/g1c  60/130/300 costanti stringa distinte (tabella dei globali grande). Atteso "G1 OK".
              Se g1c fallisce e g1a no -> problema con molti globali/costanti (indirizzi tabella, GETGLOBAL, dati statici).
 g2           record con campo mutabile + Obj.size/Obj.tag senza check/fail: atteso "abcd" e "G2 OK".
 g3           come t1 di t01a: atteso solo "G3 OK".

Quinta scala (g1 e g2 OK, g3 FAIL: il difetto e' nelle chiamate in coda dentro una funzione):
 h1_tailcalls  APPTERM con 1..4 argomenti e 0/2 variabili locali. Atteso "YYYYYYYYY" e "H OK".
 g3b_not_tail  come g3 ma l'ultimo check non e' in coda (segue print_string "."). Atteso ".G3B OK".
               Se g3 fallisce e g3b passa -> APPTERM (chiamata in coda) difettoso nell'interprete.
