let r = ref 0
let () = incr r; incr r; if !r = 2 then print_string "M5 OK" else print_string "M5 FAIL"
