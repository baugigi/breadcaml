let () = if 1 < 2 then print_string "M2 OK" else print_string "M2 FAIL"
