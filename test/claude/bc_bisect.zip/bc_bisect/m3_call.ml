let f x = x + 1
let () = if f 41 = 42 then print_string "M3 OK" else print_string "M3 FAIL"
