#!/usr/bin/env bash
# Legge i risultati di un'esecuzione: una directory con un file NOME.txt per
# test (output catturato dall'emulatore). print_newline emette CR ('\013'),
# quindi i CR vengono convertiti in LF prima dell'analisi.
# Uso: ./check_results.sh DIR_RISULTATI
d=${1:?uso: check_results.sh DIR}
ok=0; ko=0; miss=0
for f in tests/t*.ml; do
  n=$(basename "$f" .ml); r="$d/$n.txt"
  if [ ! -s "$r" ]; then printf '%-22s NESSUN OUTPUT\n' "$n"; miss=$((miss+1)); continue; fi
  last=$(tr '\r' '\n' <"$r" | sed '/^[[:space:]]*$/d' | tail -n 1)
  if [[ "$last" =~ ^T[0-9A-Z]+\ OK$ ]]; then ok=$((ok+1))
  else
    ko=$((ko+1)); printf '%-22s %s\n' "$n" "$last"
    tr '\r' '\n' <"$r" | grep '^FAIL' | head -n "${MAXFAIL:-8}" | sed 's/^/        /'
  fi
done
echo "OK: $ok   FAIL/anomali: $ko   senza output: $miss"
